app.controller('homeCtrl', function($rootScope, $scope, $location, AuthenticationService){

    /*$rootScope.href = "$scope.href";

    $scope.format = 'dd-MMMM-yyyy';

    $scope.popup1 = {
        opened: false
    };


    $scope.dateOptions = {
        dateDisabled: disabled,
        formatYear: 'yy',
        maxDate: new Date(2020, 5, 22),
        minDate: new Date(),
        startingDay: 1
    };*/


  /*  if ($rootScope.currentUser == null) {
        $window.location = "login"
    }*/

});
